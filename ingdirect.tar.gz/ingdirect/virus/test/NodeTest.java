import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class NodeTest{

    // TODO les noms des différents tests ne sont pas bons mais je les ai gardés pour rester en phase avec
    // les tests fonctionnels définis sur le site codingame

    @Test
    public void simple(){
        Node node0 = new Node(0);
        Node node1 = new Node(1);
        Node node2 = new Node(2);

        node1.addLinkTo(node0);
        node1.addLinkTo(node2);

        node2.setAsGateway();
        assertEquals("1 2", node1.getPathToGateway());
    }

    @Test
    public void severalPaths(){

        Node[] nodes = createNodes(4);


        /**
         *        1
         *     0     3
         *        2
         */

        createLinksAsSeveralPaths(nodes);



        nodes[3].setAsGateway();

        /**
         * 1 -> 3 ou
         * 2 -> 3
         */


        assertEquals("1 3" , nodes[0].getPathToGateway());
        assertEquals("2 3" , nodes[2].getPathToGateway());
    }



    @Test
    public void star(){
        Node[] nodes = createNodes(12);

        /**
         *                        4 3 2 1
         *
         *         -  5      -
         *    11   -  6      -      0
         *         -  7      -
         *
         *                          8 9 10
         */

        createLinksAsStar(nodes);
        nodes[0].setAsGateway();

        assertEquals("6 0",nodes[11].getPathToGateway());



    }

    private void createLinksAsSeveralPaths(Node[] nodes) {
        nodes[0].addLinkTo(nodes[1]);
        nodes[1].addLinkTo(nodes[0]);
        nodes[0].addLinkTo(nodes[2]);
        nodes[2].addLinkTo(nodes[0]);

        nodes[1].addLinkTo(nodes[3]);
        nodes[3].addLinkTo(nodes[1]);
        nodes[2].addLinkTo(nodes[3]);
        nodes[3].addLinkTo(nodes[2]);
    }

    private void createLinksAsStar(Node[] nodes) {
        nodes[11].addLinkTo(nodes[6]);
        nodes[6].addLinkTo(nodes[11]);

        nodes[0].addLinkTo(nodes[9]);
        nodes[9].addLinkTo(nodes[0]);

        nodes[1].addLinkTo(nodes[2]);
        nodes[2].addLinkTo(nodes[1]);

        nodes[0].addLinkTo(nodes[1]);
        nodes[1].addLinkTo(nodes[0]);

        nodes[10].addLinkTo(nodes[1]);
        nodes[1].addLinkTo(nodes[10]);

        nodes[11].addLinkTo(nodes[5]);
        nodes[5].addLinkTo(nodes[11]);

        nodes[2].addLinkTo(nodes[3]);
        nodes[3].addLinkTo(nodes[2]);

        nodes[4].addLinkTo(nodes[5]);
        nodes[5].addLinkTo(nodes[4]);

        nodes[8].addLinkTo(nodes[9]);
        nodes[9].addLinkTo(nodes[8]);

        nodes[6].addLinkTo(nodes[7]);
        nodes[7].addLinkTo(nodes[6]);

        nodes[7].addLinkTo(nodes[8]);
        nodes[8].addLinkTo(nodes[7]);

        nodes[0].addLinkTo(nodes[6]);
        nodes[6].addLinkTo(nodes[0]);

        nodes[3].addLinkTo(nodes[4]);
        nodes[4].addLinkTo(nodes[3]);

        nodes[0].addLinkTo(nodes[2]);
        nodes[2].addLinkTo(nodes[0]);

        nodes[11].addLinkTo(nodes[7]);
        nodes[7].addLinkTo(nodes[11]);

        nodes[0].addLinkTo(nodes[8]);
        nodes[8].addLinkTo(nodes[0]);

        nodes[0].addLinkTo(nodes[4]);
        nodes[4].addLinkTo(nodes[0]);

        nodes[9].addLinkTo(nodes[10]);
        nodes[10].addLinkTo(nodes[9]);

        nodes[0].addLinkTo(nodes[5]);
        nodes[5].addLinkTo(nodes[0]);

        nodes[0].addLinkTo(nodes[7]);
        nodes[7].addLinkTo(nodes[0]);

        nodes[0].addLinkTo(nodes[3]);
        nodes[3].addLinkTo(nodes[0]);

        nodes[0].addLinkTo(nodes[10]);
        nodes[10].addLinkTo(nodes[0]);

        nodes[5].addLinkTo(nodes[6]);
        nodes[6].addLinkTo(nodes[5]);
    }


    private Node[] createNodes(int numberOfNodes) {
        Node[] nodes = new Node[numberOfNodes];
        for (int i = 0; i < numberOfNodes; i++) {
            nodes[i] = new Node(i);
        }
        return nodes;
    }


}
