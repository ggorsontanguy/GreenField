import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

class Node {
    private final int id;
    private final List<Node> neighbours;
    private boolean isGateway;

    public Node(int id) {
        this.id = id;
        neighbours = new LinkedList<>();
    }

    public void addLinkTo(Node node) {
        neighbours.add(node);
    }


    public void setAsGateway() {
        isGateway = true;
    }

    @Override
    public String toString() {
        return "" + id;
    }

    private LinkedList<Node> getNodesToGateway() {
        LinkedList<Node> nodesToGateway = new LinkedList<>();
        if(isGateway){
            nodesToGateway.add(this);
            return nodesToGateway;
        }

        Optional<Node> gatewayOrLinkedTo = neighbours.stream()
                .filter(node -> node.isGateway)
                .findFirst();

        gatewayOrLinkedTo.
                ifPresent(
                node -> {
                    nodesToGateway.add(this);
                    nodesToGateway.add(node);
                });

        if(gatewayOrLinkedTo.isPresent()){
            return nodesToGateway;
        }


        // TODO : could be optimized
        // dont look for all neighbours but only neighbours not shared with the caller
        neighbours.stream()
                .map(neighbour -> neighbour.getNodesToGateway())
                .filter(nodes -> !nodes.isEmpty())
                .min((o1, o2) -> o1.size() - o2.size())
                .ifPresent(neighbourNodesToGateway -> nodesToGateway.addAll(neighbourNodesToGateway));


        return nodesToGateway;
    }


    public String getPathToGateway() {
        long start = System.currentTimeMillis();
        LinkedList<Node> linkedList = getNodesToGateway();
        long end = System.currentTimeMillis();
        System.err.println(end-start);
        // TODO unlink when called
        Node last = linkedList.pollLast();
        Node node = linkedList.pollLast();
        return ""+ node + " "+ last;
    }


}
